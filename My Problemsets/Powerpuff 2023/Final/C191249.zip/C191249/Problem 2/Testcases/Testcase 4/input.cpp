#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("Input 4.txt","w", stdout);
    long i;
    cout << 1000000 << " " << 2000000000 << endl;
    for(i=1;i<=1000000;i++)
    {
        cout << 2000000000 << " ";
    }
    fclose(stdout);
    return 0;
}