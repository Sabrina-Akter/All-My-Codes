#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("Input 5.txt","w", stdout);
    long i;
    cout << 1000000 << " " << 1000000009 << endl;
    for(i=1;i<=1000000;i++)
    {
        cout << 1900000999 << " ";
    }
    fclose(stdout);
    return 0;
}