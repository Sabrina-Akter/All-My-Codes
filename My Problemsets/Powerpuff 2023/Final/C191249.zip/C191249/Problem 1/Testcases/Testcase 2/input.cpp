#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("Input 2.txt","w", stdout);
    long long t=10, n=20, i, j;
    cout << t << endl;
    for(i=1;i<=t;i++)
    {
        cout << n << endl;
        for(j=1;j<=n;j++)
        {
            cout << 100 << " " << 10 << endl;
            cout << "Recursion DP Graph Tree Maths String Stack Queue Hashing Searching" << endl;
        }
    }
    fclose(stdout);
    return 0;
}