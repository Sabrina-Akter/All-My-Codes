#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("Input 2.txt","w", stdout);
    long long t=100, n=100000, i, j;
    cout << t << endl;
    for(i=1;i<=t;i++)
    {
        cout << n << endl;
        for(j=1;j<=n;j++)
        {
            cout << j << " ";
        }
        cout << endl;
    }
    fclose(stdout);
    return 0;
}